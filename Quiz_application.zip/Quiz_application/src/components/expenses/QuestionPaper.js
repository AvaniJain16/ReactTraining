import React from 'react';
import './QuestionPaper.css';
import Card from '../UI/Card';
import Question from './Question';
const QuestionPaper = (props) => {
   const {questions} = props;
 return <Card className='questionPaper'>
   <div >
   <div className='quizHeading'>QUIZ</div>
    <div className='totalQuestion'>Total Questions:04</div>
    <div className='timeLeft'>Time Left:15:28</div>
    <div  className='extraDiv'></div>
    </div>
    {questions.map((question) =>{ 
     return(<div> <Question key = {question.question_no} question={question}/>  <hr/></div>); 
   })} 
  <div className='submitBtn'>
   <button >Submit</button>
   </div>
   
   </Card>;
   
};

export default QuestionPaper;