
import Card from '../UI/Card';
import './Question.css';


const Question = (props) => {
    return(
        <Card className='question' >
           
           <div className='divExtraQNumber'>
            {props.question.question_no}
            </div>
            <div className='divExtraQuestion'>
                {props.question.question}
                </div>
                <div className='endFloatDiv'></div>
                <div className='divExtra1'>
                <div ><button>{props.question.option_1}</button>
                <div><button>{props.question.option_2}</button>
                <div><button>{props.question.option_3}</button>
                <div><button>{props.question.option_4}</button>
                </div>
                </div>
                </div>
                </div>
                </div>
                   <div className='questionNo'>{props.question.question_no} of 4</div>
                </Card>
                
            
    );
    
};

export default Question;