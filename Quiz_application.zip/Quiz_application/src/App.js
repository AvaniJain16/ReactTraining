import QuestionPaper from './components/expenses/QuestionPaper';
import './App.css';

function App() {
  const questions = [
    {question_no: 1, question:"Number of primitive data types in Java are?", option_1:"6", option_2:"7", option_3:"8", option_4:"9"},
    {question_no: 2, question:"What is the size of float and double in java?", option_1:"32 and 64", option_2:"64 and 64", option_3:"32 and 32", option_4:"64 and 32"},
    {question_no: 3, question:"Which of the following is not a Java features?", option_1:"Dynamic", option_2:"Architecture Neutral", option_3:"Use of pointers", option_4:"Object-oriented"},
    {question_no: 4, question:"Which of the following is true about the anonymous inner class?", option_1:"It has only methods", option_2:"Objects can't be created", option_3:"It has a fixed class name", option_4:"It has no class name"}
  ]
  return (
    <div className="App">
      <QuestionPaper questions={questions}/>
    </div>
  );
}

export default App;

